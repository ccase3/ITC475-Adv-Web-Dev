<?php

/** @var \Laravel\Lumen\Routing\Router $router */

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$router->get('/', function () use ($router) {
    return view('index');
});

$router->get('/gameState', function() use ($router) {
    $results = app('db')->select("SELECT score, done, won, keep_playing, best_score FROM game_state");
    return response()->json($results[0]);
});

$router->post('/gameState', function($current_state) use ($router) {
    $results = app('db')->update(
        "UPDATE game_state SET score = ?, done = ?, won = ?, keep_playing = ?, best_score = ?", 
        [
            $current_state['$score'], 
            $current_state['$over'],
            $current_state['$won'],
            $current_state['$keepPlaying'],
            $current_state['$bestScore']
        ]
    );
    return response()->json([]);
});
